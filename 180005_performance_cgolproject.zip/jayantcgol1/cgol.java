import java.util.Scanner;

		// Function to print next generation 
		class cgol1 extends Thread {
           
			int M,N;
			int grid[][] ;
		
public cgol1(int M, int N,int grid[][]) {
	this.M=M;
	this.N=N;
	this.grid = grid;
	
}
		public void run () 
		{ 
			int[][] future = new int[M][N]; 

			// Loop through every cell 
			for (int l = 1; l < M - 1; l++) 
			{ 
				for (int m = 1; m < N - 1; m++) 
				{ 
					// finding no Of Neighbours that are alive 
					int aliveNeighbours = 0; 
					for (int i = -1; i <= 1; i++) 
						for (int j = -1; j <= 1; j++) 
							aliveNeighbours += grid[l + i][m + j]; 

					// The cell needs to be subtracted from 
					// its neighbours as it was counted before 
					aliveNeighbours -= grid[l][m]; 

					// Implementing the Rules of Life 

					// Cell is lonely and dies 
					if ((grid[l][m] == 1) && (aliveNeighbours < 2)) 
						future[l][m] = 0; 

					// Cell dies due to over population 
					else if ((grid[l][m] == 1) && (aliveNeighbours > 3)) 
						future[l][m] = 0; 

					// A new cell is born 
					else if ((grid[l][m] == 0) && (aliveNeighbours == 3)) 
						future[l][m] = 1; 

					// Remains the same 
					else
						future[l][m] = grid[l][m]; 
				} 
			} 

			System.out.println("Next Generation"); 
			for (int i = 0; i < M; i++) 
			{ 
				for (int j = 0; j < N; j++) 
				{ 
					System.out.print(future[i][j]+ " "); 
				} 
				System.out.println();
			} 

		}}
		
		public class cgol {
			// A simple Java program to implement Game of Life 
			
				public static void main(String[] args) 
				{ 
					int M,N; 

					// Intiliazing the grid. 
					Scanner sc= new Scanner(System.in);
					System.out.println("enter the value of row and column: ");
					M=sc.nextInt();
					N=sc.nextInt();
					
					int[][] grid = new int [M][N];

					// Displaying the grid 
					System.out.println("Original Generation"); 
					for (int i = 0; i < M; i++) 
					{ 
						for (int j = 0; j < N; j++) 
						{ 
							grid[i][j] = sc.nextInt();
						} 
						
					} 
					
					
					for (int i = 0; i < M; i++) 
					{ 
						for (int j = 0; j < N; j++) 
						{ 
							System.out.print(grid[i][j]+" ");
						} 
						System.out.println(); 
					}
					
					cgol1 run= new cgol1 (M,N, grid);
					run.start();
					
				}
				
		}
